package com.eRestwebservices.Restwebservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestwebservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
